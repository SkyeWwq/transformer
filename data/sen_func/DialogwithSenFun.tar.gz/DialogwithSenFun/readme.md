Chinese Dialogue Dataset with Sentence Function Label


Introduction
This dataset contains post-response pairs collected from Weibo. Both of the posts and responses have been tokenized. Each pair has been annotated with a sentence function label, indicating which function type the responses belong to. The statistics of this dataset refer to [1].


File Description
Training set:
weibo_pair_train_pattern.post
weibo_pair_train_pattern.response
weibo_pair_train_pattern.label

Validation set:
weibo_pair_dev_pattern.post
weibo_pair_dev_pattern.response
weibo_pair_dev_pattern.label

Label:
Interrogative:	1	0	0
Imperative:	0	0	1
Declarative	0	1	0


Reference
[1] Pei Ke, Jian Guan, Minlie Huang, Xiaoyan Zhu. Generating Informative Responses with Controlled Sentence Function. In ACL 2018.